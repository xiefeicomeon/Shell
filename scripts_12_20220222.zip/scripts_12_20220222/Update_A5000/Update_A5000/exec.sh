#!/bin/bash
chmod +x $(pwd)/A5000*.sh
./A5000*.sh
cd /home/smart
rm -rf Update_A5000

