#!/bin/bash
unzip $(pwd)/ntp.zip 
cd ntp
dpkg -i *.deb
cd /home/smart
rm -rf update_ntp 

