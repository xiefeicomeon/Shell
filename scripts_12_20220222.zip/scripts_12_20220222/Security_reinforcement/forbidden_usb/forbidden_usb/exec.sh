#!/bin/bash
cd $(pwd)/6366-WQJK-security2
chmod +x *.sh
./6366-security-WQJK2.sh



cd /home/smart
rm -rf forbidden_usb

