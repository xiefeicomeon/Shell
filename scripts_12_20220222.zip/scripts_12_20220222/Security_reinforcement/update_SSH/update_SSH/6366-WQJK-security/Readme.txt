root权限下执行:./6366-security-WQJK.sh

        1.升级openssh服务
        2.关闭telnet服务
        3. 禁止Traceroute探测 请查看《禁止Traceroute探测信息.doc》文档
