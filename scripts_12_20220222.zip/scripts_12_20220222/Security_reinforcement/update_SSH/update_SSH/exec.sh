#!/bin/bash
cd $(pwd)/6366-WQJK-security
chmod +x *.sh
./6366-security-WQJK.sh
./forbid.sh
./modify_rc.local.sh

cd /home/smart
rm -rf update_SSH

