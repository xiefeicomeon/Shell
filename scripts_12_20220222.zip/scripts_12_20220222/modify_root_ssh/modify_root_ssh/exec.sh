#!/bin/bash
mv /home/smart/su /etc/pam.d 
cat /etc/pam.d/su
#清除文件
cd /home/smart
rm -rf modify_root_ssh