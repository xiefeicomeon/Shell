本目录结构如下
.
├── config_user.sh //这是用于配置普通用户的脚本，被linx.sh 调用
├── linx-intranet-monitor_2.2.2_amd64.deb //安装包，在linx.sh中完成安装
├── linx.sh //凝思厂站内网主机安全监控软件的安装脚本
├── Readme.md
├── reset //该目录和reset_package_status.sh共同用来完成恢复软件包状态的工作，也是被linx.sh调用
└── reset_package_status.sh

./linx.sh参数说明：
./linx.sh install //安装软件
./linx.sh uninstall //卸载软件
./linx.sh status //查询软件包状态
./linx.sh restore //恢复软件包状态到已卸载状态

*****************************************************
安装步骤
运行
	./linx.sh  status
查询软件包状态

（1）若查询出软件包状态为：Package xxx has been uninstalled!
则表示软件xxx尚未安装或者已卸载，这时，可运行：
	./linx.sh install
来安装软件
（2）若查询出软件包状态为：Package xxx has been installed!
则表示软件已安装，这时，可运行
	./linx.sh uninstall
来卸载软件，然后运行：
	./linx.sh install
来安装软件

*****************************************************
 

