#! /bin/bash
####################################################
# Author:zhong mao heng 
# Mail:mhzhong@linx-info.com
# Date:2018-05-30
# Function:Detect users who can log in the system and add or delete configuration information of these users
####################################################

FILE=/etc/passwd
NOLOGINUSERTYPE1=nologin
NOLOGINUSERTYPE2=false
BASHRC_CONFIG_FILE=/usr/share/smp/smp_bashrc
CSHRC_CONFIG_FILE=/usr/share/smp/smp_cshrc
PROFILE_CONFIG_FILE=/usr/share/smp/smp_profile
BASHRC=/.bashrc
CSHRC=/.cshrc
PROFILE_FILE=/etc/profile
SKEL_BASHRC=/etc/skel/.bashrc
USERID=995






function get_user_name {
	echo $1 | awk -F "#" '{print $1}'
}

function get_user_dir {
	echo $1 | awk -F "#" '{print $2}'
}

function get_user_type1 {
	t1=`echo $1 | awk -F "#" '{print $3}'`
	echo $t1 | awk -F "/" '{print $NF}'
}

function get_user_type2 {
	t2=`echo $1 | awk -F "#" '{print $2}'`
	echo $t2 | awk -F "/" '{print $2}'

}

function set_config {

  if [ -e $1 ]; then
    hnum=`grep -n -i "HEAD_OF_LINX_SMP" $1 | cut -f1 -d":"`
    tnum=`grep -n -i "TAIL_OF_LINX_SMP" $1 | cut -f1 -d":"`
    if [ -n "$hnum" ] || [ -n "$tnum" ]
    then
      echo "$1 had conifg"
      sed -i ''"$hnum"','"$tnum"'d' $1
      cat $2 >> $1
      return 1
    else
      cat $2 >> $1
      return 0
    fi
  fi

}

function reset_config {

  if [ -e $1 ]; then
    hnum=`grep -n -i "HEAD_OF_LINX_SMP" $1 | cut -f1 -d":"`
    tnum=`grep -n -i "TAIL_OF_LINX_SMP" $1 | cut -f1 -d":"`

    if [ -z "$hnum" ] || [ -z "$tnum" ]
    then
      echo "$1 had not config"
      return 1
    else
      sed -i ''"$hnum"','"$tnum"'d' $1
      return 0
    fi
  fi
}

function detect_file {
	if [[ $1 == "tcsh" ||  $1 == "csh" ]]; then
		if [ ! -e ${2}${CSHRC} ]
		then
			touch ${2}${CSHRC}
			chown $3:$3 ${2}${CSHRC}
		else
			echo "${2}${CSHRC} is exist" > /dev/null
		fi
	else
		if [ ! -e ${2}${BASHRC} ]
		then
			touch ${2}${BASHRC}
			chown $3:$3 ${2}${BASHRC}
		else
			echo "${2}${BASHRC} is exist" > /dev/null
		fi
	fi
}
function get_user_id {
	g1=`id $1 2>/dev/null | awk '{print $1}' | cut -d"=" -f2 | cut -d"(" -f1`
	echo "$g1"
}

if [ $# -lt 1 ]
then
	echo "Usage:$0 {set|reset}"
	exit -1
fi

if [ $1 != "set" ] && [ $1 != "reset" ]
then
	echo "Usage:$0 {set|reset}"
	exit -1
fi



cat $FILE | while read line
do
	info=`echo $line | awk -F ":" '{print $1 "#" $(NF-1) "#" $NF}'`
	user_name=`get_user_name $info`
	user_dir=`get_user_dir $info`
	user_type1=`get_user_type1 $info`
	user_type2=`get_user_type2 $info`
	user_id=`get_user_id $user_name`
	if [[ $user_id -gt $USERID  && $user_type1 != $NOLOGINUSERTYPE2 && $user_type1 != $NOLOGINUSERTYPE1 ]]
	then
		if [ -e $user_dir ]
		then
			echo -e "username:\e[34;1m$user_name\e[0;0m userdir:\e[34;1m$user_dir\e[0;0muserid:\e[34;1m$user_id\e[0;0m"
			if [ $1 = "set" ]
			then
				detect_file $user_type1 ${user_dir} $user_name
				
				set_config ${user_dir}${BASHRC} $BASHRC_CONFIG_FILE
				set_config ${user_dir}${CSHRC} $CSHRC_CONFIG_FILE
			elif [ $1 = "reset" ]
			then
				reset_config ${user_dir}${BASHRC}
				reset_config ${user_dir}${CSHRC}
			fi
		fi
	fi
done

exit 0

