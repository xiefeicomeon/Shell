#! /bin/bash 
ARCH=amd64

sed -i "1c Package:$1" ./reset/DEBIAN/control 
sed -i "5c Architecture:$2" ./reset/DEBIAN/control 
dpkg -b reset $1_1.0_${2}.deb
dpkg -i $1_1.0_${2}.deb
dpkg -r $1
rm $1_1.0_${2}.deb





