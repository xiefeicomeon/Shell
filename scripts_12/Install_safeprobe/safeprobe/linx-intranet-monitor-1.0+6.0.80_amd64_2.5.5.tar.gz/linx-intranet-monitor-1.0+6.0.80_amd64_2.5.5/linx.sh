#! /bin/bash
####################################################
# Author:zhong mao heng
# Mail:mhzhong@linx-info.com
# Date:2018-05-30
####################################################
####################################################
# Author:zhong mao heng
# Mail:mhzhong@linx-info.com
# Vsersion:1.1
# Date:2018-07-17 11:08
# History:Match the operating system version and the software version before installation
####################################################

INSTALL_DIR=$(pwd)
SMP=linx-intranet-monitor
GMSSL=gmssl
PASSWD=passwd
MANAGE=agent-manage
MANAGE_DEB=`find ./ -name "${MANAGE}*deb"`
SMP_DEB=`find ./ -name "${SMP}*deb"`
GMSSL_DEB=`find ./ -name "${GMSSL}*deb"`
PASSWD_DEB=`find ./ -name "${PASSWD}*deb"`
ARCH=x86_64
SERIAL_FILE=/etc/linxsn/security_sn.conf
SERIAL_FILE_BAK=/etc/linxsn/security_sn.conf.bak
CONFIG_FILE=/usr/share/smp/linx_config
CONFIG_FILE_BAK=/usr/share/smp/linx_config.bak
CONFIG_FILE_EN=/usr/share/smp/linx_config.en
LCM_INSTALL_DIR=$( find ${INSTALL_DIR} -name "linx-cmd-monitor*LINX*_amd64")
VERSION_CHECK_DIR=$( find ${INSTALL_DIR} -name "versioncheck" | head -1)

#OS_VERSION=`cat /etc/issue | tail -n 3| head -n 1|awk '{print $5}' | cut -d "." -f3`
#PACK_TYPE=40
#
#
#if [ "$OS_VERSION" != "$PACK_TYPE" ]; then
#	echo -e "\e[31mOperating system version and software version do not match!!!\e[0;0m"
#	os=`cat /etc/issue | tail -n 3 | head -n 1 |awk '{print $5}'`
#	software=`echo $SMP_PKG |awk -F"#" '{print $2}'`
#	echo -e "\e[31mOperating system version is:\e[0;0m\e[41;37m$os\e[0;0m"
#	echo -e "\e[31mSoftware version is:\e[0;0m\e[41;37m$software\e[0;0m"
#	echo -e "\e[31mPlease re-select the software that matches the operating system version.\e[0;0m"
#	exit 1
#fi

function sm2_config {
	cd /usr/share/smp
	/usr/local/gmssl/bin/gmssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:sm2p256v1 -out private.pem
	chmod 644 private.pem
}

function split_en {
	rm -rf /usr/share/smp/linx_config_*.en
	split -b 500 $CONFIG_FILE -d -a 4 /usr/share/smp/linx_config-
	for i in `ls /usr/share/smp/linx_config-*`;do
		tmp=`echo $i | sed 's/-/_/'`
		/usr/local/gmssl/bin/gmssl pkeyutl -encrypt -in $i -pkeyopt ec_scheme:sm2 -inkey /usr/share/smp/private.pem -out ${tmp}.en
		rm -rf $i

	  done

}

function remove_ver_check {
    echo "start remove versioncheck"
    if [ -d "/usr/local/versionckeck" ]
    then
        rm -rf /usr/local/versionckeck
    fi
}

function en_config {

	if [ -e "$CONFIG_FILE" ];then
	  size=`ls -l $CONFIG_FILE | awk -F ' ' '{print $5}'`
	  if [ $size -ge 600 ];then
      split_en
      if [ -e $CONFIG_FILE_EN ];then
        rm $CONFIG_FILE_EN
      fi
	  else
      /usr/local/gmssl/bin/gmssl pkeyutl -encrypt -in /usr/share/smp/linx_config -pkeyopt ec_scheme:sm2 -inkey /usr/share/smp/private.pem -out /usr/share/smp/linx_config.en
      if [ -e "/usr/share/smp/linx_config_0001.en" ];then
        rm -rf /usr/share/smp/linx_config_*.en
      fi
	  fi

		rm $CONFIG_FILE
	fi
}

function de_config {

  if [ -e "$CONFIG_FILE" ];then  #卸载时配置文件处于解密状态,清空内容
      echo  > $CONFIG_FILE
  fi

	if [ -e "$CONFIG_FILE_EN" ];then
		/usr/local/gmssl/bin/gmssl pkeyutl -decrypt -in /usr/share/smp/linx_config.en -pkeyopt ec_scheme:sm2 -inkey /usr/share/smp/private.pem -out /usr/share/smp/linx_config
		rm $CONFIG_FILE_EN
	elif [ -e "/usr/share/smp/linx_config_0001.en" ];then #多个加密配置文件
	  for i in `ls /usr/share/smp/linx_config_*.en`;do
		tmp=`echo $i | sed 's/.en//g' | sed 's/\/usr\/share\/smp\///g'`
		/usr/local/gmssl/bin/gmssl pkeyutl -decrypt -in $i -pkeyopt ec_scheme:sm2 -inkey /usr/share/smp/private.pem -out $HOME/$tmp
		cat $HOME/$tmp >> /usr/share/smp/linx_config
		rm -rf $HOME/$tmp
    done
    rm -rf /usr/share/smp/linx_config_*.en
	fi
}

function mdsum {
	/usr/bin/md5sum /sbin/linx_smp | awk '{print $1}' > /usr/share/smp/bin_md5.txt
	/usr/bin/md5sum /etc/init.d/linx_smpd | awk '{print $1}' > /usr/share/smp/smpd_md5.txt
	/usr/bin/md5sum /usr/share/smp/check_server_rocky.sh | awk '{print $1}' > /usr/share/smp/baseline_md5.txt
}

function get_pack_status {
	str=`dpkg -l |grep $SMP | awk '{print $2}'`
	if [ -z "$str" ]; then
		echo "2"
		return 2
	fi
	t1=`dpkg -l $SMP  | tail -n1 | awk '{print $1}'`
	if [ "$t1" = "ii" ]
	then
		echo "1"
		return 1
	elif [ "$t1" = "rc" ]
	then
		echo "2"
		return 2
	else
		echo "-1"
		return -1
	fi
}
user=`whoami`
if [ "root" != $user ];then
    echo "Please run this with root"
    exit -1
fi

case "$1" in
	install)
		if [ -e "$SMP_DEB" ]
		then
			deb_status=`get_pack_status`
			if [ $deb_status -eq 1 ]
			then
				echo "DEB $SMP has been installed!"
				echo "Please run $0 status to check DEB status"
				echo "exit -1"
				exit -1
			else
				echo "Starting install $SMP_DEB"
				dpkg -i $SMP_DEB
			fi
		fi

		if [ -e "$GMSSL_DEB" ]
		then
			echo "Starting install $GMSSL_DEB"
			dpkg -i $GMSSL_DEB
		fi
		if [ -e "$PASSWD_DEB" ]
		then
			echo "Starting install $PASSWD_DEB"
			dpkg -i $PASSWD_DEB
		fi
		if [ -e "$MANAGE_DEB" ]
		then
			dpkg -l | grep $MANAGE
			if [ $? -eq 0 ]
			then
				dpkg -r $MANAGE
			fi
			echo "Starting install $MANAGE_DEB"
			dpkg -i $MANAGE_DEB
		fi

		if [ -e "$SERIAL_FILE_BAK" ]; then
			mv $SERIAL_FILE_BAK $SERIAL_FILE
		fi

		if [ -e "$CONFIG_FILE_BAK" ]; then
			mv $CONFIG_FILE_BAK $CONFIG_FILE
		fi

		./init.sh
		sm2_config
		en_config
		mdsum
				if [ -d "$LCM_INSTALL_DIR" ]
		then
			cd $LCM_INSTALL_DIR
			./lcm_install.sh install
			cd ${INSTALL_DIR}
		fi
		if [ -d "${VERSION_CHECK_DIR}" ]
		then
		    echo "start install version check!"
		    cd ${VERSION_CHECK_DIR}
		    chmod u+x install.sh
		    ./install.sh
		fi

		;;
	uninstall)
		deb_status=`get_pack_status`
		if [ $deb_status -ne 1 ]
		then
			echo "DEB $SMP  has been unstalled!"
			echo "Please run $0 status to check DEB status"
			echo "exit -1"
			exit -1
		fi
		/etc/init.d/linx_smpd stop
		de_config
		echo "Starting uninstall $SMP"
		if [ -e "$SERIAL_FILE" ]; then
			echo "Backup serial number"
			cp $SERIAL_FILE $SERIAL_FILE_BAK
		fi
		if [ -e "$CONFIG_FILE" ]; then
			echo "Backup linx_config"
			cp $CONFIG_FILE $CONFIG_FILE_BAK
		fi
		dpkg -r $SMP
		dpkg -r $MANAGE

		dpkg -l | grep linx-cmd-monitor
		if [ $? -eq 0 ] && [ -d "$LCM_INSTALL_DIR" ]
		then
			# shellcheck disable=SC2164
			cd ${LCM_INSTALL_DIR}

			if [ $? -eq 0 ]
			then
			    ./lcm_install.sh uninstall
			fi
		else
		    ./config_user.sh reset
		fi
		if [ -d "${VERSION_CHECK_DIR}" ]
		then
		    echo "start uninstall version check!"
		    cd ${VERSION_CHECK_DIR}
		    chmod u+x uninstall.sh
		    ./uninstall.sh
		fi

		remove_ver_check

		;;
	status)
		deb_status=`get_pack_status`
		if [ $deb_status -eq 1 ]
		then
			echo "DEB $SMP has been installed!"
			dpkg -l $SMP
		elif [ $deb_status -eq 2 ]
		then
			echo "DEB $SMP has been uninstalled"
			dpkg -l $SMP
		else
			echo "Package $SMP status is unhealthy!!! or Never installed"
			echo "Please run dpkg -l $SMP to check it!!"
			echo "IF it is unhealthy try to solve by running $0 restore"
			echo "If it can't be solved, then solve it manually."
			dpkg -l $SMP
		fi
		;;
	restore)
		deb_status=`get_pack_status`
		if [ $deb_status -ne -1 ]
		then
			echo "Package $SMP status is healthy!"
			echo "Starting restore DEB status"
			./reset_package_status.sh $DEB $ARCH
		fi
		;;
	*)
		echo "Usage:$0 {install|uninstall|status|restore}"
		;;
esac


exit 0


