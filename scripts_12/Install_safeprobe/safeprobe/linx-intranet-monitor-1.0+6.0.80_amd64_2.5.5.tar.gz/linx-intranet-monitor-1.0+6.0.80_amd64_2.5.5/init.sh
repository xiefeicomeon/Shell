#! /bin/bash  

SOFTWARE_NAME=bind9 
INSTALLED=ii 
UNINSTALLED=un 
SOFTWARE_STATUS=`dpkg -l $SOFTWARE_NAME 2>/dev/null | tail -n 1 | awk '{print $1}'` 


dpkg -l $SOFTWARE_NAME > /dev/null 2>&1 
if [ $? -ne 0 ]; then 
	echo "No such package($SOFTWARE_NAME)" 
	exit 1 
fi 

if [ "$SOFTWARE_STATUS" = "$INSTALLED" ]; then 
	echo "Uninstalling $SOFTWARE_NAME" 
	dpkg -P  $SOFTWARE_NAME > /dev/null 2>&1 
elif [ "$SOFTWARE_STATUS" = "$UNINSTALLED" ]; then 
	echo "bind9 has been uninstall" 
else 
	echo "Please check the package($SOFTWARE_NAME) status manually" 
fi 
