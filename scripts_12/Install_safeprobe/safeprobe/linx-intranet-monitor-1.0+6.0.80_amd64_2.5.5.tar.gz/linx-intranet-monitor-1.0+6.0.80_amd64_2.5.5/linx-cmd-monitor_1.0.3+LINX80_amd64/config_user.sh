#! /bin/bash
####################################################
# Author:zhong mao heng
# Mail:mhzhong@linx-info.com
# Date:2018-05-30
# Function:Detect users who can log in the system and add or delete configuration information of these users
####################################################

FILE=/etc/passwd
NOLOGINUSERTYPE1=nologin
NOLOGINUSERTYPE2=false
BASHRC_CONFIG_FILE=/usr/share/lcm/config/lcm_bashrc
PROFILERC_CONFIG_FILE=/usr/share/lcm/config/bash_profile
BASH_BASHRC_CONFIG_FILE=/usr/share/lcm/config/lcm_bash.bashrc
CSH_LOGIN_CONFIG_FILE=/usr/share/lcm/config/lcm_csh.login
CSH_CSHRC_CONFIG_FILE=/usr/share/lcm/config/lcm_csh.cshrc
CSHRC_CONFIG_FILE=/usr/share/lcm/config/lcm_cshrc
PROFILE_CONFIG_FILE=/usr/share/lcm/config/lcm_profile
XSESSION_CONFIG_FILE=/usr/share/lcm/config/lcm_xsession
XSESSIONRC_CONFIG_FILE=/usr/share/lcm/config/lcm_xsessionrc
XSESSION_D_CONFIG_FILE=/usr/share/lcm/config/lcm_xsession_config
BASHRC=/.bashrc
CSHRC=/.cshrc
PROFILERC=/.profile
PROFILE=/etc/profile
BASH_BASHRC=/etc/bash.bashrc
CSH_LOGIN=/etc/csh.login
CSH_CSHRC=/etc/csh.cshrc
SKEL_BASHRC=/etc/skel/.bashrc
SKEL_PROFILE=/etc/skel/.profile
SKEL_XSESSIONRC=/etc/skel/.xsessionrc
SKEL_CSHRC=/etc/skel/.cshrc
LIGHTDM_XSESSION_FILE=/etc/X11/Xsession
LIGHTDM_XSESSION_D_FILE=/etc/X11/Xsession.d/45lcm_xsessionrc
LIGHTDM_XSESSION_D_DIR=/etc/X11/Xsession.d/
GDM3_XSESSION_FILE=/etc/gdm3/Xsession
XSESSIONRC_FILE=/.xsessionrc
USERID=995
ERROR_COUNT=0
declare -a ERROR_ARRY

if [ ! -e ${SKEL_BASHRC} ]; then
	touch ${SKEL_BASHRC}
fi
if [ ! -e ${SKEL_CSHRC} ]; then
	touch ${SKEL_CSHRC}
fi

function get_user_name {
	echo $1 | awk -F "#" '{print $1}'
}

function get_user_dir {
	echo $1 | awk -F "#" '{print $2}'
}

function get_user_type1 {
	t1=$(echo $1 | awk -F "#" '{print $3}')
	echo $t1 | awk -F "/" '{print $NF}'
}

function get_user_type2 {
	t2=$(echo $1 | awk -F "#" '{print $2}')
	echo $t2 | awk -F "/" '{print $2}'

}

function get_user_group {
	echo $(groups $1 | awk '{print $3}')
}

function set_config {

	if [ -e $1 ]; then
		bnum=$(grep -n -i "BEGIN for linx_smp" $1 | cut -f1 -d":")
		enum=$(grep -n -i "END for linx_smp" $1 | cut -f1 -d":")

		hnum=$(grep -n -i "HEAD_OF_LINX_LCM" $1 | cut -f1 -d":")
		tnum=$(grep -n -i "TAIL_OF_LINX_LCM" $1 | cut -f1 -d":")
	fi

	if [ -n "$bnum" ] || [ -n "$enum" ]; then
		sed -i ''"$bnum"','"$enum"'d' $1 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
		bnum=""
		enum=""
	fi

	if [ -n "$hnum" ] || [ -n "$tnum" ]; then
		sed -i ''"$hnum"','"$tnum"'d' $1 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
		if [ -e $2 ]; then
			cat $2 >>$1
			hnum=""
			tnum=""
		fi
		return 1
	else
		if [ -e $2 ]; then
			cat $2 >>$1
		fi
		hnum=""
		tnum=""
		return 0
	fi
}

function reset_config {

	if [ -e $1 ]; then
		hnum=$(grep -n -i "HEAD_OF_LINX_LCM" $1 | cut -f1 -d":")
		tnum=$(grep -n -i "TAIL_OF_LINX_LCM" $1 | cut -f1 -d":")
	fi
	if [ -z "$hnum" ] || [ -z "$tnum" ]; then
		return 1
	elif [ -e $1 ]; then
		sed -i ''"$hnum"','"$tnum"'d' $1 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
		return 0
	fi
}

function set_xsession {

	if [ -e ${LIGHTDM_XSESSION_FILE} ]; then
		linenum_lightdm=$(grep -n -i "export LOGINPID=" ${LIGHTDM_XSESSION_FILE} | cut -f1 -d":")
	fi
	if [ -e ${GDM3_XSESSION_FILE} ]; then
		linenum_gdm3=$(grep -n -i "export LOGINPID=" ${GDM3_XSESSION_FILE} | cut -f1 -d":")
	fi

	if [ -e ${XSESSION_CONFIG_FILE} ]; then
		LOGINPID_CMD=$(cat ${XSESSION_CONFIG_FILE})
	else
		return 1
	fi
	if [ ! -e $1 ]; then
		touch $1
	fi

	if [ -z "$linenum_lightdm" ] && [ -n "$LOGINPID_CMD" ] && [ -f ${LIGHTDM_XSESSION_FILE} ]; then
		sed -i '/PROGNAME=Xsession/i'"$LOGINPID_CMD"'' ${LIGHTDM_XSESSION_FILE} 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
	fi

	if [ -z "$linenum_gdm3" ] && [ -n "$LOGINPID_CMD" ] && [ -f ${GDM3_XSESSION_FILE} ]; then
		sed -i '/PROGNAME=Xsession/i'"$LOGINPID_CMD"'' ${GDM3_XSESSION_FILE} 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
	fi

	if [ -e ${XSESSIONRC_CONFIG_FILE} ]; then

		set_config $1 ${XSESSIONRC_CONFIG_FILE}
	fi

	if [ -d $LIGHTDM_XSESSION_D_DIR ] && [ -e $XSESSION_D_CONFIG_FILE ]; then
		set_config $LIGHTDM_XSESSION_D_FILE $XSESSION_D_CONFIG_FILE
	fi
}

function set_file_owner {
	if [ -e $1 ]; then
		if [ ! -z $3 ]; then
			chown $2:$3 $1
		else
			chown $2 $1
		fi
		if [ $? -ne 0 ]; then
			echo "set the $1 authority fail!"
			exit -1
		fi
	fi
}

function reset_xsession {
	if [ -e ${LIGHTDM_XSESSION_FILE} ]; then
		sed -i '/export LOGINPID=/d' $LIGHTDM_XSESSION_FILE 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
	fi

	if [ -e ${GDM3_XSESSION_FILE} ]; then
		sed -i '/export LOGINPID=/d' $GDM3_XSESSION_FILE 2>/dev/null
		if [ $? -ne 0 ]; then
			ERROR_ARRY[${ERROR_COUNT}]=$1
			ERROR_COUNT=$((ERROR_COUNT + 1))
		fi
	fi

	reset_config $1

	if [ -e $LIGHTDM_XSESSION_D_FILE ]; then
		rm -rf $LIGHTDM_XSESSION_D_FILE
	fi

}

function set_profilerc {
	if [ ! -e $1 ]; then
		touch $1
	fi
	set_config $1 $2
}

function set_skel_profilerc {
	if [ ! -e $1 ]; then
		cat $2 >$1
	fi
}

function detect_file {
	if [ -e $1 ]; then
		echo "$1 is exist" >/dev/null
		return 0
	else
		touch $1
		chown $2:$2 $1 2>/dev/null
	fi
}
function get_user_id {
	g1=$(id $1 2>/dev/null | awk '{print $1}' | cut -d"=" -f2 | cut -d"(" -f1)
	echo "$g1"
}

if [ $# -lt 1 ]; then
	echo "Usage:$0 {set|reset}"
	exit -1
fi

if [ $1 != "set" ] && [ $1 != "reset" ]; then
	echo "Usage:$0 {set|reset}"
	exit -1
fi

while read line; do
	info=$(echo $line | awk -F ":" '{print $1 "#" $(NF-1) "#" $NF}')
	user_name=$(get_user_name $info)
	user_dir=$(get_user_dir $info)
	user_type1=$(get_user_type1 $info)
	user_type2=$(get_user_type2 $info)
	user_id=$(get_user_id $user_name)
	user_group=$(get_user_group $user_name)
	if [[ $user_type1 != ${NOLOGINUSERTYPE2} && $user_type1 != ${NOLOGINUSERTYPE1} ]]; then
		if [ -e $user_dir ]; then
			echo -e "username:\e[34;1m$user_name\e[0;0m userdir:\e[34;1m$user_dir\e[0;0muserid:\e[34;1m$user_id\e[0;0m"
			if [ $1 = "set" ]; then
				detect_file ${user_dir}${BASHRC} $user_name
				detect_file ${user_dir}${CSHRC} $user_name
				detect_file $PROFILE $user_name

				set_config ${user_dir}${BASHRC} $BASHRC_CONFIG_FILE
				set_file_owner ${user_dir}${BASHRC} $user_name $user_group
				set_config $PROFILE $PROFILE_CONFIG_FILE
				set_config $SKEL_BASHRC $BASHRC_CONFIG_FILE
				set_config $SKEL_CSHRC $CSHRC_CONFIG_FILE
				set_config $SKEL_XSESSIONRC $XSESSIONRC_CONFIG_FILE
				set_config ${user_dir}${CSHRC} $CSHRC_CONFIG_FILE
				set_file_owner ${user_dir}${CSHRC} $user_name $user_group
				set_config ${BASH_BASHRC} ${BASH_BASHRC_CONFIG_FILE}
				set_config ${CSH_CSHRC} ${CSH_CSHRC_CONFIG_FILE}
				set_config ${CSH_LOGIN} ${CSH_LOGIN_CONFIG_FILE}
				set_xsession ${user_dir}${XSESSIONRC_FILE}
				set_file_owner ${user_dir}${XSESSIONRC_FILE} $user_name $user_group
				set_profilerc ${user_dir}${PROFILERC} ${PROFILERC_CONFIG_FILE}
				set_file_owner ${user_dir}${XSESSIONRC_FILE} $user_name $user_group
				set_skel_profilerc $SKEL_PROFILE $PROFILERC_CONFIG_FILE
			elif [ $1 = "reset" ]; then
				reset_config ${user_dir}${BASHRC}
				reset_config $PROFILE
				reset_config $SKEL_BASHRC
				reset_config $SKEL_PROFILE
				reset_config $SKEL_CSHRC
				reset_config ${user_dir}${CSHRC}
				reset_config ${BASH_BASHRC}
				reset_config ${CSH_CSHRC}
				reset_config ${CSH_LOGIN}
				reset_config ${user_dir}${PROFILERC}
				reset_config $SKEL_XSESSIONRC
				reset_xsession ${user_dir}${XSESSIONRC_FILE}
			fi
		fi
	fi
done <$FILE

if [ $ERROR_COUNT -gt 0 ]; then
	echo "there have $ERROR_COUNT file \"${ERROR_ARRY[*]}\" ,which set config flase ,please set them by yourself!!!"
fi
exit 0
