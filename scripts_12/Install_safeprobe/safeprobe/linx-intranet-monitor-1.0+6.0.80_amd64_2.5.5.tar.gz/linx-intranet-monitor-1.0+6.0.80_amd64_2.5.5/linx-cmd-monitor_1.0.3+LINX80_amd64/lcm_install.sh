#!/bin/bash
WORKDIR=/tmp/lcmp
OLDBASH=${WORKDIR}/oldbash
OLDTCSH=${WORKDIR}/oldtcsh



if [ ! -d ${WORKDIR} ];then
	mkdir ${WORKDIR}
fi


  [ -f ${OLDBASH} ] && rm -f ${OLDBASH}
  [ -f ${OLDTCSH} ] && rm -f ${OLDTCSH}
	echo "/root" > ${OLDBASH}
	grep -Eiv "false|nologin|sync|var" /etc/passwd|grep home|grep csh| awk -F: '{print $6}' > ${OLDTCSH}
	grep -Eiv "false|nologin|sync|var" /etc/passwd|grep home|grep -v csh| awk -F: '{print $6}' >> ${OLDBASH}

user=`whoami`
if [ "root" != $user ]; then

    echo "Run script user is not root,Please run it by root! "
    exit 1
fi

if [ $# -lt 1 ]; then
    echo "Usage:${0} [install|unintsll]"
    exit 1

fi

LCM_NAME=linx_cmd_monitor
backup_dir=/opt/lcm

function error_printer() {
    case "$1" in
        0)
            echo "Great! ${2} successful!!!"
            ;;
        1)
            echo "The installation package does not exist"
            ;;
        2)
            echo "installation(${2}) failed"
            ;;
        3)
            echo "(${2}) not installed"
            ;;
        4)
            echo "set rights(${2}) error"
            ;;
        5)
            echo "create file(${2}) error"
            ;;
        6)
            echo "set capability(${2}) error"
            ;;
        7)
            echo "create dir(${2} error"
            ;;
        8)
            echo "cp(${2}) error"
            ;;
        *)
            echo "Usage:$0 {1|2|3|4}"
    esac
}

function lcm_install_deb() {

    echo "start lcm_install_deb"
    LCM=linx-cmd-monitor
    lcm_deb=`find ./ -name "${LCM}*.deb"`
    if [ ! -e ${lcm_deb} ]; then
        error_printer 1
        exit 1
    fi

    dpkg -l | grep ${LCM} | grep -iv grep
    if [ $? -eq 0 ]
    then
        backup_config
    fi

    dpkg -i ${lcm_deb}
    if [ $? -ne 0 ]
	then
		error_printer 2
		exit 2
	fi

}


function lcm_uninstall_deb() {

    echo "start lcm_uninstall_deb"
    LCM=linx-cmd-monitor
    dpkg -l | grep ${LCM} | grep -iv grep
    if [ $? -eq 0 ]; then
        backup_config
        dpkg -P ${LCM}
    else
        error_printer 3 ${LCM}
        exit 3
    fi
}


function lcm_install_pkg() {

    echo "start lcm_install_pkg"
    LCM=linx_cmd_monitor
    lcm_pkg=`find ./ -name "${LCM}*.pkg.tar.gz"`
    if [ ! -e ${lcm_pkg} ]; then
        error_printer 1
        exit 1
    fi

    pkginfo -i | grep ${LCM} | grep -iv grep
    if [ $? -eq 0 ]; then

        backup_config
        pkgadd -u ${lcm_pkg}
        if [ $? -ne 0 ]; then
            error_printer 2 "pkgadd -u ${lcm_pkg}"
            exit 2
        fi
    else
        pkgadd -f ${lcm_pkg}
        if [ $? -ne 0 ]; then
            error_printer 2 "pkgadd -f ${lcm_pkg}"
            exit 2
        fi

    fi
}

function lcm_uninstall_pkg() {

    echo "start lcm_uninstall_pkg"
    LCM=linx_cmd_monitor
    pkginfo -i | grep ${LCM} | grep -iv grep
    if [ $? -eq 0 ]; then
        backup_config
        pkgrm ${LCM}
    else
        error_printer 3 ${LCM}
        exit 3
    fi
}

function set_rights() {

    [ -d /usr/share/lcm ] && chmod 777 /usr/share/lcm
    if [ $? -ne 0 ]; then
        error_printer 4 "chmod 777 /usr/share/lcm"
        exit 4
    fi

    [ -d /usr/share/lcm/config ] && chmod 777 /usr/share/lcm/config
    if [ $? -ne 0 ]; then
        error_printer 4 "chmod 777 /usr/share/lcm/config"
        exit 4
    fi

    if [ ! -e /var/log/lcm.log ]; then
        touch /var/log/lcm.log
        if [ $? -ne 0 ]; then
            error_printer 5 "touch /var/log/lcm.log"
            exit 5
        fi
    fi

    chmod 777 /var/log/lcm.log
    chmod 777 /usr/share/lcm/config/linx_zlog.lock
    chmod 777 /usr/share/lcm/config/linx_zlog.conf
    chmod 777 /usr/share/lcm/tools/cmd_filter.sh

}

function set_capability() {
    setcap "cap_dac_read_search,cap_fowner,cap_dac_override+ep" /usr/share/lcm/bin/lcm_script
    if [ $? -ne 0 ]
    then
        error_printer 6 "setcap cap_dac_read_search,cap_fowner,cap_dac_override+ep /usr/share/lcm/bin/lcm_script"
        exit 6
    fi
}

function backup_config() {

    if [ ! -d ${backup_dir} ]
    then
        mkdir -p /opt/lcm
        if [ $? -ne 0 ]
        then
            error_printer 7 "mkdir -p /opt/lcm Please mkdir /opt/lcm by yourself"
            exit 7
        fi
    fi

    cp -r /usr/share/lcm/config ${backup_dir}
    if [ $? -ne 0 ]
    then
        error_printer 8 "cp -r /usr/share/lcm/config ${backup_dir}"
        exit 8
    fi
}

function restore_config() {

    if [ -d ${backup_dir} ]
    then
        cp ${backup_dir}/config/*.json /usr/share/lcm/config
        if [ $? -ne 0 ]
        then
            error_printer 8 "cp ${backup_dir}/config/*.json /usr/share/lcm/config"
            exit 8
        fi
    fi
}

function get_deb_status {
	str=`dpkg -l |grep ${LCM_NAME} | awk '{print $2}'`
	if [ -z "${str}" ]; then
		echo "can't find the deb"

	fi
	t1=`dpkg -l ${LCM_NAME}  | tail -n1 | awk '{print $1}'`
	if [ "$t1" = "ii" ]
	then
		echo "linx_cmd_monitor has been installed"
		dpkg -l ${LCM_NAME}
	elif [ "$t1" = "rc" ]
	then
		echo "linx_cmd_monitor has been uninstalled"
		dpkg -l ${LCM_NAME}
	else
		echo "error deb"
	fi
}

case "$1" in
    install)
        pkg_type=`find ./ -name "*.pkg.tar.gz"`
        if [ ! -z "${pkg_type}" ]; then
            lcm_install_pkg

        else
            lcm_install_deb

        fi
        set_rights
        set_capability
        ./config_user.sh set
        restore_config
        error_printer 0 "install lcm"
        ;;

    uninstall)
        pkg_type=`find ./ -name "*.pkg.tar.gz"`
        if [ ! -z "${pkg_type}" ]; then
            lcm_uninstall_pkg
        else
            lcm_uninstall_deb
        fi
        ./config_user.sh reset
        error_printer 0 "uninstall lcm"
        ;;
    status)
        pkg_type=`find ./ -name "*.pkg.tar.gz"`
        if [ ! -z "${pkg_type}" ]; then
            pkginfo -i | grep ${LCM_NAME} | grep -iv grep
            if [ $? -eq 0 ]; then
                echo "linx_cmd_monitor has been installed"
            fi
        else
            get_deb_status
        fi
        ;;
    *)
        echo "Usage:${0} [install|unintsll|status]"
esac

