#!/bin/sh

Install()
{
	if [ ! -d "$install_dir" ];then
		mkdir -p $install_dir
	fi
	if [ ! -d "$result_dir" ];then
		mkdir -p $result_dir
	fi
	cp ./* $install_dir -f
	chmod +x $install_dir/*
	cd $install_dir
	touch xxxaaa!!!.sk
	chmod 400 xxxaaa!!!.sk
}

ADDAUTORUN()
{
	if [ -f "/etc/rc.d/rc.local" ]
	then
		RCLOCAL_FILE="/etc/rc.d/rc.local"
	elif [ -f "/etc/rc.local" ]
	then
		RCLOCAL_FILE="/etc/rc.local"
	else 
		RCLOCAL_FILE="/etc/rc.local"
		touch $RCLOCAL_FILE
		chmod 755 $RCLOCAL_FILE
		cat > $RCLOCAL_FILE  <<-EOF
#!/bin/sh -e
#STATE_GRID_start
/usr/local/versioncheck/versioncheck &
exit 0
#STATE_GRID_end
EOF
			   
	fi
	startLine=`sed -n '/#STATE_GRID_end/=' $RCLOCAL_FILE`
	if [[ x"$startLine" = x ]];then
		sed -i '/^exit 0/d' $RCLOCAL_FILE
		cat <<-EOF >> $RCLOCAL_FILE
#STATE_GRID_start
/usr/local/versioncheck/versioncheck &
exit 0
#STATE_GRID_end
EOF
	fi
	$install_dir/versioncheck &
}

install_dir=/usr/local/versioncheck
result_dir=/usr/local/versioncheck/checkresult
RCLOCAL_FILE=""

Install
ADDAUTORUN




