#! /bin/bash

VERSION_DIR=/usr/local/versioncheck/
PID=$(ps -ef | grep /usr/local/versioncheck/versioncheck | grep -v grep | awk '{print $2}')

function reset_config {
    if [ -f $1 ];then
        hnum=`grep -n -i "#STATE_GRID_start" $1 | cut -f1 -d":"`
        tnum=`grep -n -i "#STATE_GRID_end" $1 | cut -f1 -d":"`

        if [ -z "$hnum" ] || [ -z "$tnum" ]
        then
          echo "$1 had not config"
          return 1
        else
          sed -i ''"$hnum"','"$tnum"'d' $1
          echo "exit 0" >> $1
          return 0
        fi
    fi
}


if [ -d ${VERSION_DIR} ];then
    rm -r ${VERSION_DIR}
fi
if [ -n ${PID} ];then
    /bin/kill -9 ${PID}
fi

reset_config "/etc/rc.d/rc.local"
reset_config "/etc/rc.local"
