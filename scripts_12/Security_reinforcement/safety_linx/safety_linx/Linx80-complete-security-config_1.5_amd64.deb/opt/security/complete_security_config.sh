#!/bin/bash

TIME=`date "+%Y-%m-%d_%H-%M"`
SEC_PATH=/opt/security/complete_backup

# 系统新建用户后，需要先修改密码
function myuseradd()
{
        cat <<EOF  > /usr/bin/myuseradd
if [ \$# != 2 ];then
echo "Usage:\$0 -m [username]"
        exit 1;
fi
useradd \$*
echo \$2:rocky | chpasswd
passwd -e \$2
read -p "Please input your new passwd:"  pw
echo \$2:\$pw | chpasswd
echo -e "\033[33m->Change Passwd Success!\033[0m"

EOF
setcap  "cap_mac_admin+ei cap_chown,cap_dac_override,cap_fowner+ep" /usr/sbin/useradd
setcap  "cap_mac_admin+ei cap_chown,cap_dac_override,cap_fowner+ep" /usr/bin/passwd
setcap  "cap_mac_admin+ei cap_chown,cap_dac_override,cap_fowner+ep" /usr/sbin/userdel

chmod  710 /usr/sbin/useradd
chmod  710 /usr/sbin/userdel

chown root.secadmin /usr/sbin/useradd
chown root.secadmin /usr/sbin/userdel

chown root:secadmin /usr/bin/myuseradd
chmod 750 /usr/bin/myuseradd
}

# sshd_config默认安全项配置 
function sshd_config()
{
cp -r --preserve=all --parents /etc/ssh/sshd_config /opt/security/complete_backup/$TIME
	cat <<EOF > /etc/ssh/sshd_config
# Package generated configuration file
# See the sshd_config(5) manpage for details

# What ports, IPs and protocols we listen for
Port 22
# Use these options to restrict which interfaces/protocols sshd will bind to
#ListenAddress ::
#ListenAddress 0.0.0.0
Protocol 2
macs hmac-sha1
# HostKeys for protocol version 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_dsa_key
#Privilege Separation is turned on for security

# Logging
SyslogFacility AUTH
LogLevel INFO

# Authentication:
LoginGraceTime 120
PermitRootLogin  no
MaxAuthTries 5
#DenyUsers sysadmin secadmin audadmin netadmin
StrictModes yes

#PubkeyAuthentication yes
#AuthorizedKeysFile     /dev/null

# Don't read the user's ~/.rhosts and ~/.shosts files
IgnoreRhosts yes
# similar for protocol version 2
HostbasedAuthentication no
# Uncomment if you don't trust ~/.ssh/known_hosts for RhostsRSAAuthentication
#IgnoreUserKnownHosts yes

# To enable empty passwords, change to yes (NOT RECOMMENDED)
PermitEmptyPasswords no

# Change to yes to enable challenge-response passwords (beware issues with
# some PAM modules and threads)
ChallengeResponseAuthentication no

# Change to no to disable tunnelled clear text passwords
#PasswordAuthentication yes

# Kerberos options
#KerberosAuthentication no
#KerberosGetAFSToken no
#KerberosOrLocalPasswd yes
#KerberosTicketCleanup yes

# GSSAPI options
#GSSAPIAuthentication no
#GSSAPICleanupCredentials yes

X11Forwarding yes
X11DisplayOffset 10
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
#UseLogin no

#MaxStartups 10:30:60
Banner none

# Allow client to pass locale environment variables
AcceptEnv LANG LC_*

Subsystem sftp /usr/lib/openssh/sftp-server

# Set this to 'yes' to enable PAM authentication, account processing,
# and session processing. If this is enabled, PAM authentication will
# be allowed through the ChallengeResponseAuthentication and
# PasswordAuthentication.  Depending on your PAM configuration,
# PAM authentication via ChallengeResponseAuthentication may bypass
# the setting of "PermitRootLogin without-password".
MaxAuthTries 5
# If you just want the PAM account and session checks to run without
# PAM authentication, then enable this but set PasswordAuthentication
# and ChallengeResponseAuthentication to 'no'.

UsePAM yes

EOF
}

# 登录超时脚本
function login_timeout()
{
cp -r --preserve=all --parents /etc/profile /opt/security/complete_backup/$TIME
cp -r --preserve=all --parents /etc/csh.cshrc /opt/security/complete_backup/$TIME
sed -i '/#bash_tmout/,/#bash_tmout/d' /etc/profile
cat <<EOF >> /etc/profile
#bash_tmout
echo \`who am i\` | grep -E "[[:digit:]]*\.[[:digit:]]*\.[[:digit:]]*\.[[:digit:]]*" 
if [ \$? -eq 0 ]; then
	readonly TMOUT=18000;
fi
#bash_tmout
EOF

sed -i '/#csh_autologout/,/#csh_autologout/d' /etc/csh.cshrc
cat <<EOF >> /etc/csh.cshrc
#csh_autologout
echo \`who am i\` | grep -E "[[:digit:]]*\.[[:digit:]]*\.[[:digit:]]*\.[[:digit:]]*" 
if ( \$? == 0 ) then
	set -r autologout=300
endif
#csh_autologout
EOF
}

# 禁用光驱(直接调用/usr/bin/remove_built-in_cdrom start)

# 禁用usb存储设备(直接调用/usr/bin/remove_built-in_usb start)

# 禁用虚拟终端(直接调用/usr/bin/stop_tty start)


# 禁用telnet和swat、ftp
function prohibit_telnet_swat()
{
cp -r --preserve=all --parents /etc/inetd.conf  /opt/security/complete_backup/$TIME
sed -i '/telnet/c#telnet         stream  tcp     nowait  telnetd /usr/sbin/tcpd  /usr/sbin/in.telnetd' /etc/inetd.conf
sed -i '/swat/c#swat            stream  tcp     nowait.400      root    /usr/sbin/tcpd  /usr/sbin/swat' /etc/inetd.conf
/etc/init.d/openbsd-inetd restart
chkconfig proftpd off
systemctl stop proftpd 
}

# 身份鉴别口令复杂度
function Password_complexity()
{
cp -r --preserve=all --parents /etc/pam.d/common-password  /opt/security/complete_backup/$TIME
sed -i '/pam_cracklib.so/cpassword  required    pam_cracklib.so retry=3 minlen=8 difok=3 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1  reject_username enforce_for_root' /etc/pam.d/common-password
sed -i "/^.*pam_unix.so.*$/c\password	[success=2 default=ignore]	pam_unix.so obscure use_authtok try_first_pass sha512 remember=1" /etc/pam.d/common-password
}

# 口令90天定期更换
function Change_pw_regularly()
{
cp -r --preserve=all --parents /etc/login.defs  /opt/security/complete_backup/$TIME
sed -i '/^PASS_MAX_DAYS/cPASS_MAX_DAYS   90' /etc/login.defs
}

# 口令过期前10天，应提示修改
function Pw_overdue_warning()
{
sed -i '/^PASS_WARN_AGE/cPASS_WARN_AGE   10' /etc/login.defs
}

# 登录地址限制access.so 
function Login_address_limit()
{
cp -r --preserve=all --parents /etc/pam.d/sshd  /opt/security/complete_backup/$TIME
sed -i '/pam_access.so/caccount required pam_access.so' /etc/pam.d/sshd
}

# 登录失败锁定
function Logon_timeout_lock()
{
cp -r --preserve=all --parents /etc/pam.d/common-auth  /opt/security/complete_backup/$TIME

sed -i "/^.*pam_tally.so.*$/d" /etc/pam.d/common-auth
sed -i "/^.*pam_tally2.so.*$/d" /etc/pam.d/common-auth
sed -i "/^# pam-auth-update(8)/a\auth required pam_tally.so per_user unlock_time=600 onerr=succeed audit deny=5" /etc/pam.d/common-auth
}

function security_config()
{
read -p "Please input your order (config/recover/status) " order
case $order in
		config )
	if [ ! -f /opt/security/simple_backup/.simple ]; then

		if [ ! -f /opt/security/complete_backup/.complete ]; then

    			echo "[ complete_security_config ]...............[ Configing ]"
			mkdir -p $SEC_PATH/$TIME
			echo "$SEC_PATH/$TIME" > $SEC_PATH/.complete
			myuseradd
			sshd_config
			/etc/init.d/ssh restart
			login_timeout
			remove_built-in_cdrom start
			remove_built-in_usb start
			stop_tty start
			prohibit_telnet_swat
			Password_complexity
			Change_pw_regularly
			Pw_overdue_warning
			Login_address_limit
			Logon_timeout_lock
			ban_vnc start
			ban_xmanager start
		else
  			echo "the system alreadly has complete_security_config"

		fi

	else
  		echo "the system alreadly has simple_security_config"

	fi		
			;;
		recover )
		if [ -f /opt/security/complete_backup/.complete ]; then
			echo "[ complete_security_config ]...............[ Recovering ]"
			cp -r --preserve=all `cat $SEC_PATH/.complete`/etc/* /etc
			rm -f /opt/security/complete_backup/.complete
			remove_built-in_cdrom stop
			remove_built-in_usb stop
			stop_tty stop
			/etc/init.d/ssh restart
			/etc/init.d/openbsd-inetd restart
			chkconfig proftpd on
			ban_vnc stop
			ban_xmanager stop
			echo "ok! the complete_security_config recovering is finished"
		elif [ -f /opt/security/simple_backup/.simple ]; then
			echo "error! the system has alreadly simple_security_config, please use simple_security_config to recover"
		else
  			echo "ok! the system has alreadly recovered complete_security_config"
		fi
			;;
		status )
	if [ ! -f /opt/security/simple_backup/.simple ]; then

		if [ ! -f /opt/security/complete_backup/.complete ]; then

    			echo "the system doesn't has any security_config"
			
		else
  			echo "the system alreadly has complete_security_config"

		fi

	else
  		echo "the system alreadly has simple_security_config"

	fi		
		
			;;
		*)
			echo "Usage: \$0 {config|recover}"
			exit 1
			;;
	esac

	exit 0

}

security_config
